<?php

class DCApi
{

    /**
     * Set Command To Device
     * @param $device
     * @param $command
     * @param $res
     */
    public static function command($device,$command,$res){

        $connection=new Connection();
        $setting_zr=new SettingsZR($connection->db);
        $device_entity=new Device($connection->db);
        $settings=$setting_zr->settings();
        $command_list=[
            0=>"0xA100",
            1=>"0xA101"
        ];

        $api_http=new ApiHTTP();

        $url=$settings['protocol']."://".$settings['ip'].":".$settings['port']."/DeviceControlWebService/command/".$settings['zr']."/".$device."/".$command_list[$command];
        $credentials = base64_encode($settings['username'].':'.$settings['password']);
        $headers[]="Authorization: Basic ".$credentials;
        $response_command=$api_http->put($url,null,$headers);
        Log::set(date("Y-m-d H:i:s")." - Send Command : $url");

        $httpcode=$response_command['httpcode'];
        if($httpcode===200){

            $data=$response_command['output'];
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $response=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                if ($response->status == "0"){
                    Log::set(date("Y-m-d H:i:s")." - Send Command : 204 \nNo Content");
                    $res->response('',204);
                }else{
                    Log::set(date("Y-m-d H:i:s")." - Send Command : $httpcode \nError internal server.");
                    $res->response('',500);
                }

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - Send Command : 422 \n$response_xml");
                $res->response($response_xml,422);
            }

        }else{
            if($httpcode==401){
                $response_xml=Body::error_response(101,'Access Denied','Access Denied to ZR.');
                Log::set(date("Y-m-d H:i:s")." - Send Command : 401 \n$response_xml");
                $res->response($response_xml,$httpcode);
            }elseif ($httpcode==0){

                $return=$device_entity->create_update_device($settings['zr'],8);
                if($return){
                    $response_xml=Body::error_response(0,'Failed',$response_command['error']);
                    Log::set(date("Y-m-d H:i:s")." - Send Command : $httpcode \n$response_xml");
                    $res->response($response_xml,500);
                }
            }else{
                $response_xml=Body::error_response($httpcode,'Failed',$response_command['error']);
                Log::set(date("Y-m-d H:i:s")." - Send Command : $httpcode \n$response_xml");
                $res->response($response_xml,500);
            }
        }
    }

    /**
     * Get List of events
     * @return SimpleXMLElement
     */
    public static function getEvents($res){

        $connection=new Connection();
        $setting_zr=new SettingsZR($connection->db);
        $device_entity=new Device($connection->db);
        $settings=$setting_zr->settings();

        $api_http=new ApiHTTP();

        $url=$settings['protocol']."://".$settings['ip'].":".$settings['port']."/DeviceControlWebService/events/".$settings['event_id'];
        $credentials = base64_encode($settings['username'].':'.$settings['password']);
        $headers[]="Authorization: Basic ".$credentials;
        $events=$api_http->get($url,null,$headers);
        Log::set(date("Y-m-d H:i:s")." - Get List of Events : $url");

        $httpcode=$events['httpcode'];
        if($httpcode==200){

            $data=$events['output'];
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $_return_devices=array();
                $events=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                Log::set(date("Y-m-d H:i:s")." - List of Events : \n".json_encode($events));
                $events=json_decode(json_encode($events), TRUE);
                if(array_key_exists('event',$events)){

                    $events=$events['event'];

                    if(sizeof($events)>0 and array_key_exists(0,$events)){
                        $last_event=end($events);
                        $last_even_id=$last_event['sequence-number'];
                        $setting_zr->update_event_id((int)$last_even_id-1);
                    }

                    if(sizeof($events)>1 and array_key_exists(0,$events)){
                        $ids_devices=self::unique_multidim_array($events,'field-device-number');
                        foreach ($ids_devices as $device){
                            $_id_device=$device['field-device-number'];
                            $device_events=self::getEventsByDevice($events,$_id_device);
                            $status_of_device=end($device_events);
                            self::create_update_device($status_of_device,$device_entity);

                            $_return_devices[]=$status_of_device;
                        }

                        return $_return_devices;
                    }else{

                        $ids_devices=self::unique_multidim_array(array($events),'field-device-number');
                        foreach ($ids_devices as $device){
                            $_id_device=$device['field-device-number'];
                            $device_events=self::getEventsByDevice(array($events),$_id_device);
                            $status_of_device=end($device_events);
                            self::create_update_device($status_of_device,$device_entity);

                            $_return_devices[]=$status_of_device;
                        }

                        return $_return_devices;

                    }
                }

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - Get Events : 422 \n$response_xml");
                $res->response($response_xml,422);
            }

        }else{
            if($httpcode==401){
                $response_xml=Body::error_response(101,'Access Denied','Access Denied to ZR.');
                Log::set(date("Y-m-d H:i:s")." - Get Events : 401 \n$response_xml");
                $res->response($response_xml,$httpcode);
            }elseif ($httpcode==0){

                $return=$device_entity->create_update_device($settings['zr'],8);
                if($return){
                    $response_xml=Body::error_response(0,'Failed',$events['error']);
                    Log::set(date("Y-m-d H:i:s")." - Get Events : 500 \n$response_xml");
                    $res->response($response_xml,500);
                }
            }else{

                $response_xml=Body::error_response($httpcode,'Failed',$events['error']);
                Log::set(date("Y-m-d H:i:s")." - Get Events : $httpcode \n$response_xml");
                $res->response($response_xml,500);
            }
        }
    }

    /**
     * Get the unique ID
     * @param $array
     * @param $key
     * @return array
     */
    private static function unique_multidim_array($array, $key) {
        $temp_array = array();
        $key_array = array();

        foreach($array as $val) {
            if (!in_array($val[$key], $key_array)) {
                $key_array[] = $val[$key];
                $temp_array[] = $val;
            }
        }
        return $temp_array;
    }

    /**
     * Create Or Update device Status
     * @param $device
     * @param $device_entity
     */
    private static function create_update_device($device,$device_entity){

        if($device_entity->device($device['id'])===false){
            $device_entity->create_update_device($device['id'],$device['status']);
        }else{
            $device_entity->create_update_device($device['id'],$device['status']);
        }
    }

    /**
     * Get List events By Device ID
     * @param $events
     * @param $device_id
     * @return array
     */
    private static function getEventsByDevice($events,$device_id){

        $events_list=array();
        foreach ($events as $event){
            if($event['field-device-number']===$device_id){
                $events_list[]=[
                    "id"=>$event['field-device-number'],
                    "status"=>$event['device-state'],
                    "datetime"=>$event['event-date-time']
                ];
            }
        }

        return $events_list;
    }

    /**
     * Device(s) Status
     * @param $res
     */
    public static function devices_status($res,$device_id){

        $connection=new Connection();
        $device=new Device($connection->db);
        if($device_id===null){

            $result=$device->devices();
            $response_xml=Body::device_status($result);
            Log::set(date("Y-m-d H:i:s")." Device Status : 200 OK \n$response_xml");
            $res->response($response_xml,200);

        }else{

            $result=$device->device($device_id);
            if($result===false){

                $response_xml=Body::error_response(-1,'Undefined Device','Device not found.');
                Log::set(date("Y-m-d H:i:s")." Device Status : 500 \nDevice not found.");
                $res->response($response_xml,500);
            }else{

                $response_xml=Body::device_status(array($result));
                Log::set(date("Y-m-d H:i:s")." Device Status : 200 OK \n$response_xml");
                $res->response($response_xml,200);
            }

        }


    }

    /**
     * Get All List of events
     * @param $res
     * @return mixed|SimpleXMLElement
     */
    public static function list_of_events($res){

        $connection=new Connection();
        $setting_zr=new SettingsZR($connection->db);
        $settings=$setting_zr->settings();

        $api_http=new ApiHTTP();

        $url=$settings['protocol']."://".$settings['ip'].":".$settings['port']."/DeviceControlWebService/events/".$settings['event_id'];
        $credentials = base64_encode($settings['username'].':'.$settings['password']);
        $headers[]="Authorization: Basic ".$credentials;
        $events=$api_http->get($url,null,$headers);
        Log::set(date("Y-m-d H:i:s")." - Get List of Events : $url");
        $events_list=array();

        $httpcode=$events['httpcode'];
        if($httpcode==200){

            $data=$events['output'];
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $_return_devices=array();
                $events=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                Log::set(date("Y-m-d H:i:s")." - List of Events : $httpcode \n".json_encode($events));
                $events=json_decode(json_encode($events), TRUE);
                $events=$events['event'];

                return $events;

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - List of Events : 422 \n$response_xml");
                $res->response($response_xml,422);
            }

        }else{
            if($httpcode==401){
                $response_xml=Body::error_response(101,'Access Denied','Access Denied.');
                Log::set(date("Y-m-d H:i:s")." - List of Events : $httpcode \n$response_xml");
                $res->response($response_xml,$httpcode);
            }else{
                $res->response('',$httpcode);
            }
        }

    }

}