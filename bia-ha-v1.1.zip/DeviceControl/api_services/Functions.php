<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 16/08/2018
 * Time: 08:23
 */
class Functions
{

    public static function verif_authorization($authorization){

        $val=explode(" ",trim($authorization));
        if(sizeof($val)>1){
            $user_pass=$val[1];
            $user_pass=base64_decode($user_pass);
            $user_pass=explode(":",$user_pass);
            if(sizeof($user_pass)>1){
                $username=$user_pass[0];
                $password=$user_pass[1];
            }
        }

        $content_auth=file_get_contents("Files/authorization.json");
        $json=json_decode($content_auth,true);
        if($json['authorization']===$authorization){
            return true;
        }else{
            return false;
        }
    }

    /**
     * Get Name Device
     * @param $device_id
     * @return mixed
     */
    public static function nameDevice($device_id){

        $connection=new Connection();
        $device=new Device($connection->db);
        $result=$device->device($device_id);

        return $result['name'];
    }

    public static function settings_ftp(){

        $content_auth=file_get_contents("Files/settings_ftp.json");
        $json=json_decode($content_auth,true);

        return $json;
    }

    /**
     * Get the unique ID
     * @param $array
     * @param $key
     * @return array
     */
    public static function unique_multidim_array($array, $key) {
        $temp_array = array();
        $key_array = array();

        foreach($array as $val) {
            if (!in_array($val[$key], $key_array)){
                $key_array[] = $val[$key];
                $temp_array[] = $val;
            }
        }
        return $key_array;
    }

    /**
     * Get Value of key devices or Facility
     * @param $key
     * @param $type
     * @return string
     */
    public static function key_value($key,$type){

        $content_auth=file_get_contents("Files/keys.json");
        $json=json_decode($content_auth,true);

        if(array_key_exists($type,$json)){
            if(array_key_exists($key,$json[$type])){
                return $key.' - '.$json[$type][$key];
            }else{
                return $key;
            }
        }else{
            return '#####';
        }
    }
}