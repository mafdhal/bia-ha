<?php

class ApiHTTP
{

    /**
     * Request
     * @param $uri
     * @param $method
     * @param $data
     * @return \SimpleXMLElement
     */
    public function request($uri, $method, $data,$headers)
    {
        try{

            // Initialise cURL
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $uri);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            if($headers!=null){
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            }
            if($method=="POST"){
                curl_setopt($ch, CURLOPT_POST, 1);
            }else{
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
            }
            if($method!='GET'){
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }

            $output = curl_exec($ch);
            $httpd=curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_error=curl_error($ch);

            curl_close($ch);
            $return=[
                'httpcode'=>$httpd,
                'error'=>$curl_error,
                'output'=>$output
            ];

            return $return;

        }catch (ServerException $e){

                $content =$e->getResponse()->getBody()->getContents();
                $xml = new \SimpleXMLElement($content);
                $object = json_decode(json_encode($xml));
                return $object;
        }
    }

    /**
     * Post data
     * @param $uri
     * @param $data
     * @return \SimpleXMLElement
     */
    public function post($uri, $data,$headers)
    {
        try {
            return $this->request($uri, 'POST',$data,$headers);
        }catch (RequestException $e) {
            return $e->getCode();
        }
    }

    /**
     * Get data
     * @param $uri
     * @param $data
     * @return \SimpleXMLElement
     */
    public function get($uri, $data,$headers)
    {
        return $this->request($uri, 'GET', $data,$headers);
    }

    /**
     * PUT Request
     * @param $uri
     * @param $data
     * @param $headers
     * @return int|mixed|\SimpleXMLElement
     */
    public function put($uri, $data,$headers)
    {
        try {
            return $this->request($uri, 'PUT', $data,$headers);
        } catch (RequestException $e) {
            return $e->getCode();
        }

    }

}