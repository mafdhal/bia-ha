<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 04/05/2018
 * Time: 15:15
 */
class Body
{

    private static $ls_status=[
        0=>"Undefined",
        1=>"In Operation",
        2=>"In Operation",
        3=>"In Operation",
        4=>"In Operation",
        5=>"In Operation",
        6=>"Out of Operation",
        7=>"Out of Operation",
        8=>"Out of Operation"
    ];

    /**
     * GET Version
     * @param $version
     * @return string
     */
    public static function version($version){

        $xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        $xml.="<version>".$version."</version>";

        return $xml;
    }

    /**
     * Get List Alarms
     * @param $array
     * @return string
     */
    public static function list_alarms($array){

        $xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        $xml.="<alarms>";
        foreach ($array as $item){
            $xml.="<alarm>";
            $xml.="<date>".$item['date']."</date>";
            $xml.="<lpn>".$item['lpn']."</lpn>";
            $xml.="<category>".$item['category']."</category>";
            $xml.="<description>".$item['description']."</description>";
            $xml.="</alarm>";
        }
        $xml.="</alarms>";

        return $xml;
    }

    /**
     * Get List Alarms Triggered
     * @param $array
     * @return string
     */
    public static function list_alarms_triggered($array){

        $xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        $xml.="<alarms>";
        foreach ($array as $item){
            $xml.="<alarm>";
            $xml.="<date>".$item['date']."</date>";
            $xml.="<deviceid>".$item['deviceid']."</deviceid>";
            $xml.="<lpn>".$item['lpn']."</lpn>";
            $xml.="<category>".$item['category']."</category>";
            $xml.="<description>".$item['description']."</description>";
            $xml.="</alarm>";
        }
        $xml.="</alarms>";

        return $xml;
    }

    /**
     * Get a device status
     * @param $array
     * @return string
     */
    public static function device_status($array){

        $xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        $xml.="<devices>";
        foreach ($array as $item){
            $xml.="<device>";
            $xml.="<id>".$item['id']."</id>";
            $xml.="<name>".$item['name']."</name>";
            $xml.="<status>".self::$ls_status[$item['status']]."</status>";
            $xml.="<last_update>".str_replace(' ','T',$item['last_update'])."</last_update>";
            $xml.="</device>";
        }

        $xml.="</devices>";

        return $xml;
    }

    /**
     * Reformat ERROR XML Response
     * @param $code
     * @param $shrtMsg
     * @param $message
     * @return string
     */
    public static function error_response($code,$shrtMsg,$message){

        $xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        $xml.="<ErrorResponse>";
        $xml.="<Code>".$code."</Code>";
        $xml.="<ShortMsg>".$shrtMsg."</ShortMsg>";
        $xml.="<Message>".$message."</Message>";
        $xml.="</ErrorResponse>";

        return $xml;
    }
}