<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 31/08/2018
 * Time: 11:17
 */
class Log
{

        public static function set($log_msg){

            self::wh_log($log_msg);
        }

        private static function wh_log($log_msg)
        {
            $log_filename = "logs";
            $log_file_data = $log_filename.'/log_' . date('Y-m-d') . '.log';
            if (!file_exists($log_filename))
            {
                // create directory/folder uploads.
                mkdir($log_filename, 0777, true);
                if(!file_exists($log_file_data)){
                    $fh = fopen($log_file_data, 'wb');

                    $date=date('Y-m-d');
                    file_put_contents($log_file_data, "************** Start Log For Day : '" . $date . "'**********" . "\n\n", FILE_APPEND);
                }
            }else{
                if(!file_exists($log_file_data)){
                    $fh = fopen($log_file_data, 'wb');

                    $date=date('Y-m-d');
                    file_put_contents($log_file_data, "************** Start Log For Day : '" . $date . "'**********" . "\n\n", FILE_APPEND);
                }
            }

            file_put_contents($log_file_data, $log_msg . "\n", FILE_APPEND);
        }

}