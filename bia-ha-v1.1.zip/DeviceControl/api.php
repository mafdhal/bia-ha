<?php

    require_once("Rest.inc.php");
    require_once("api_services/ApiHTTP.php");
    require_once("api_services/Log.php");
    require_once("api_services/Body.php");
    require_once("api_services/Functions.php");
    require_once("connection/Connection.php");

    //Entity
    require_once("Entity/Versions.php");
    require_once("Entity/Alarms.php");
    require_once("Entity/Push.php");
    require_once("Entity/SettingsZR.php");
    require_once("Entity/Device.php");
    require_once("Entity/Transactions.php");

    // Controller
    require_once("Controller/AlarmController.class.php");
    require_once("Controller/VersionController.class.php");
    require_once("Controller/PushController.class.php");
    require_once("Controller/ExportPackage.php");

    //Api Services
    require_once("api_services/DCApi.php");

	class API extends Connection {


		public function __construct(){
			parent::__construct();
		}
		
		/*
		 * Public method for access api.
		 * This method dynmically call the method based on the query string
		 *
		 */
		public function processApi(){

			$requests=explode("/",$_REQUEST['request']);
			$func = strtolower(trim(str_replace("/","",$_REQUEST['request'])));
			$func=$requests[0];
			if((int)method_exists($this,$requests[0]) > 0)
				$this->$func();
			else
				$this->response('',404);
		}

        /**
         * Get Version
         */
		private function version(){

            if($this->get_request_method() != "GET"){
                $this->response('',406);
            }

            $headers = apache_request_headers();
            if(isset($headers['Authorization'])){
                $_return=Functions::verif_authorization($headers['Authorization']);
                if($_return){
                    $version=VersionController::getVersion();
                    @$valid_xml=simplexml_load_string($version);
                    if($valid_xml!==false){

                        $this->response($version,200);

                    }else{
                        $this->response('',422);
                    }
                }else{
                    // Forbidden
                    $response_xml=Body::error_response(101,'Access Denied.','Verify your Authorization value.');
                    $this->response($response_xml,403);
                }
            }else{
                $this->response('',401);
            }
        }

        /**
         * Get List of Alarms
         */
        private function alarms(){

            $data = file_get_contents("php://input");
            $headers = apache_request_headers();
            $_request=$_REQUEST;
            $from=null;
            $to=null;
            if(array_key_exists('From',$_request) and isset($_request['From']) and $_request['From']!=""){
                $from=$_request['From'];
            }if(array_key_exists('To',$_request) and isset($_request['To']) and $_request['To']!=""){
                $to=$_request['To'];
            }

            if(isset($headers['Authorization'])){

               $_return=Functions::verif_authorization($headers['Authorization']);
                if($_return){

                    $method=$this->get_request_method();
                    switch ($method) {
                        case 'GET':
                            AlarmController::list_alarms($this,$from,$to); break;
                        case 'POST':
                            AlarmController::create($this,$data); break;
                        case 'PUT':
                            AlarmController::update($this,$data); break;
                        case 'DELETE':
                            AlarmController::delete($this,$data); break;
                    }

                }else{
                    // Forbidden
                    $response_xml=Body::error_response(101,'Access Denied.','Verify your Authorization value.');
                    $this->response($response_xml,403);
                }
            }else{
                // UnAuthorized
                $this->response('',401);
            }
        }

        /**
         * PUSH Alarm
         */
        private function alarm(){

            if($this->get_request_method()!=="POST"){
                $this->response('',406);
            }

            $data = file_get_contents("php://input");
            $headers = apache_request_headers();

            if(isset($headers['Authorization'])){

                $_return=Functions::verif_authorization($headers['Authorization']);
                if($_return){
                    PushController::push($this,$data);
                }else{
                    // Forbidden
                    $response_xml=Body::error_response(101,'Access Denied.','Verify your Authorization value.');
                    $this->response($response_xml,403);
                }

            }else{
                // Unauthorized
                $this->response('',401);
            }

        }

        /**
         * Device Control by device ID
         */
        private function deviceStatus(){

            if($this->get_request_method()!=="GET"){
                $this->response('',406);
            }

            $headers = apache_request_headers();
            if(isset($headers['Authorization'])){

                $_return=Functions::verif_authorization($headers['Authorization']);
                if($_return){
                    $_request=$_REQUEST;
                    if(array_key_exists('deviceid',$_request) and isset($_request['deviceid']) and !empty($_request['deviceid'])){

                        $device_id=$_request['deviceid'];
                        DCApi::devices_status($this,$device_id);

                    }else{
                        DCApi::devices_status($this,null);
                    }
                }else{
                    // Forbidden
                    $response_xml=Body::error_response(101,'Access Denied.','Verify your Authorization value.');
                    $this->response($response_xml,403);
                }

            }else{
                $this->response('',401);
            }

        }

        /**
         * Send Command To Device
         */
        private function command(){

            if($this->get_request_method()!=="PUT"){
                $this->response('',406);
            }
            $headers = apache_request_headers();
            if(isset($headers['Authorization'])){

                $_return=Functions::verif_authorization($headers['Authorization']);
                if($_return){
                    $_request=$_REQUEST;
                    $command_list=array(0,1);
                    if(array_key_exists('deviceid',$_request) and isset($_request['deviceid']) and !empty($_request['deviceid'])){

                        if(array_key_exists('cmd',$_request) and isset($_request['cmd']) and in_array($_request['cmd'],$command_list)){

                            $deviceid=$_request['deviceid'];
                            $cmd=$_request['cmd'];
                            DCApi::command($deviceid,$cmd,$this);

                        }else{
                            $response_xml=Body::error_response(-1,'Invalid Command','Command is required and must be 0 or 1.');
                            $this->response($response_xml,500);
                        }
                    }else{

                        $response_xml=Body::error_response(-1,'Invalid Device ID','Device ID is required.');
                        $this->response($response_xml,500);
                    }
                }else{
                    // Forbidden
                    $response_xml=Body::error_response(101,'Access Denied.','Verify your Authorization value.');
                    $this->response($response_xml,403);
                }

            }else{
                $this->response('',401);
            }
        }

        // CRON for insert the last status of device
        private function cron_device_status(){

            $events=DCApi::getEvents($this);

        }

        /**
         * Get List of Alarms Triggered
         */
        private function alarmsTriggered(){

            if($this->get_request_method()!=="GET"){
                $this->response('',406);
            }
            $headers = apache_request_headers();
            if(isset($headers['Authorization'])){

                $_return=Functions::verif_authorization($headers['Authorization']);
                if($_return){

                    $method=$this->get_request_method();
                    switch ($method) {
                        case 'GET':
                            PushController::list_alarms_triggered($this); break;
                    }

                }else{
                    // Forbidden
                    $response_xml=Body::error_response(101,'Access Denied.','Verify your Authorization value.');
                    $this->response($response_xml,403);
                }
            }else{
                // UnAuthorized
                $this->response('',401);
            }
        }

        /**
         * WebService LPN Triggered with jar File.
         */
        private function lpn_triggered(){

            $_request=$_REQUEST;

            if(array_key_exists('lpn',$_request) and array_key_exists('date',$_request) and array_key_exists('deviceid',$_request)){

                $data=array("lpn"=>$_request['lpn'],"date"=>$_request['date'],"deviceid"=>$_request['deviceid']);
                $data=(object)$data;

                PushController::lpn_triggered($this,$data);
            }
        }

        /**
         * Data Export Package
         * @return bool
         */
        private function data_export_package(){

            $settings_ftp=Functions::settings_ftp();
            $outputs=ExportPackage::ftp_output($settings_ftp);
            ExportPackage::ftp_input($settings_ftp,$outputs);

        }
    }

	// Initiate Library
	$api = new API;
	$api->processApi();

?>