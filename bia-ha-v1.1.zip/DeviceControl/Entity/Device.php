<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 09:19
 */
class Device
{

    private $conn;
    private $table_name = "device";

    public $device_id;
    public $name;

    /**
     * Versions constructor.
     * @param $conn
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    /**
     * @return mixed
     */
    public function getConn()
    {
        return $this->conn;
    }

    /**
     * @param mixed $conn
     */
    public function setConn($conn)
    {
        $this->conn = $conn;
    }

    /**
     * @return mixed
     */
    public function getDeviceId()
    {
        return $this->device_id;
    }

    /**
     * @param mixed $device_id
     */
    public function setDeviceId($device_id)
    {
        $this->device_id = $device_id;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }



    /**
     * Get Device By device_id
     */
    public function device($device_id){

        $query="SELECT * FROM ".$this->table_name." WHERE `device_id`='".$device_id."'";

        $statement=$this->conn->prepare($query);
        $statement->execute();

        $result=$statement->fetch(PDO::FETCH_ASSOC);
        if($result['device_id']>0){
            $device=[
                "id"=>$result['device_id'],
                "name"=>$result['name'],
                "status"=>((int)$result['status']==8 and (int)$result['status_camera']!=null)?(int)$result['status_camera']:(int)$result['status'],
                "last_update"=>$result['last_update']
            ];

            return $device;
        }else{
            return false;
        }
    }

    /**
     * Get List of Device
     * @return array
     */
    public function devices(){

        $query="SELECT * FROM ".$this->table_name;

        $statement=$this->conn->prepare($query);
        $statement->execute();

        $lists=array();
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)){

            $lists[]=[
                "id"=>$row['device_id'],
                "name"=>$row['name'],
                "status"=>((int)$row['status']==8 and (int)$row['status_camera']!=null)?(int)$row['status_camera']:(int)$row['status'],
                "last_update"=>$row['last_update']
            ];
        }

        return $lists;
    }

    /**
     * Create or Update a Device
     * @param $status
     * @param $device_id
     * @return bool
     */
    public function create_update_device($device_id,$status){

        $device=$this->device($device_id);
        if((int)$device_id>0){
            if($device===false){

                $sql="INSERT INTO " . $this->table_name . " SET `device_id`=:device_id, `name`=:device_id, `status`=:status, `last_update`=:last_update";
                Log::set(date("Y-m-d H:i:s")." - Create Device : $device_id with status=$status \n$sql");
            }else{
                $sql="UPDATE " . $this->table_name . " SET `status`=:status, `last_update`=:last_update WHERE `device_id`=:device_id";
                Log::set(date("Y-m-d H:i:s")." - Update Device : $device_id with status=$status \n$sql");
            }

            $stmt = $this->conn->prepare($sql);

            $last_update=(new DateTime())->format('Y-m-d H:i');
            $stmt->bindParam(":status", $status);
            $stmt->bindParam(':device_id', $device_id);
            $stmt->bindParam(':last_update', $last_update);

            if($stmt->execute()){
                return true;
            }

            return false;
        }

    }


}