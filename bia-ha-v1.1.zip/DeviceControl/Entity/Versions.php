<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 09:19
 */
class Versions
{

    private $conn;
    private $table_name = "versions";

    public $version;

    /**
     * Versions constructor.
     * @param $conn
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
    }


    /**
     * @return mixed
     */
    public function getVersion()
    {
        return $this->version;
    }

    /**
     * @param mixed $version
     */
    public function setVersion($version)
    {
        $this->version = $version;
    }

    /**
     * Get Version
     */
    public function version(){

        $query="SELECT * FROM ".$this->table_name;

        $statement=$this->conn->prepare($query);
        $statement->execute();

        return $statement;

    }
}