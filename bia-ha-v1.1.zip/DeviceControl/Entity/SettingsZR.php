<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 09:19
 */
class SettingsZR
{

    private $conn;
    private $table_name = "settings_zr";

    public $protocol;
    public $ip;
    public $port;
    public $username;
    public $password;
    public $zr;

    /**
     * SettingsZR constructor.
     * @param $conn
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
    }


    /**
     * @return mixed
     */
    public function getProtocol()
    {
        return $this->protocol;
    }

    /**
     * @param mixed $protocol
     */
    public function setProtocol($protocol)
    {
        $this->protocol = $protocol;
    }

    /**
     * @return mixed
     */
    public function getIp()
    {
        return $this->ip;
    }

    /**
     * @param mixed $ip
     */
    public function setIp($ip)
    {
        $this->ip = $ip;
    }

    /**
     * @return mixed
     */
    public function getPort()
    {
        return $this->port;
    }

    /**
     * @param mixed $port
     */
    public function setPort($port)
    {
        $this->port = $port;
    }

    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $username
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getZr()
    {
        return $this->zr;
    }

    /**
     * @param mixed $zr
     */
    public function setZr($zr)
    {
        $this->zr = $zr;
    }



    /**
     * Get Version
     */
    public function settings(){

        $query="SELECT * FROM ".$this->table_name;

        $statement=$this->conn->prepare($query);
        $statement->execute();

        $result=$statement->fetch(PDO::FETCH_ASSOC);
        $settings=[
            "protocol"=>$result['protocol'],
            "ip"=>$result['ip'],
            "port"=>$result['port'],
            "username"=>$result['username'],
            "password"=>$result['password'],
            "zr"=>$result['zr'],
            "event_id"=>$result['event_id']
        ];

        return $settings;

    }

    // UPDATE EVENT ID
    public function update_event_id($event_id){

        $query="SELECT * FROM ".$this->table_name;

        $statement=$this->conn->prepare($query);
        $statement->execute();
        $result=$statement->fetch(PDO::FETCH_ASSOC);

        $sql="UPDATE " . $this->table_name . " SET `event_id`=:event_id WHERE `id`=:id";
        $stmt = $this->conn->prepare($sql);

        $stmt->bindParam(":event_id", $event_id);
        $stmt->bindParam(':id', $result['id']);

        if($stmt->execute()){
            return true;
        }

        return false;
    }
}