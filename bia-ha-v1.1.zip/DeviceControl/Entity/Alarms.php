<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 09:15
 */
class Alarms
{

    private $conn;
    private $table_name = "alarms";

    public $id;
    public $date;
    public $lpn;
    public $category;
    public $description;

    /**
     * Alarms constructor.
     * @param $conn
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
    }


    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getLpn()
    {
        return $this->lpn;
    }

    /**
     * @param mixed $lpn
     */
    public function setLpn($lpn)
    {
        $this->lpn = $lpn;
    }

    /**
     * @return mixed
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * @param mixed $category
     */
    public function setCategory($category)
    {
        $this->category = $category;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * GET List Alarms
     */
    public function list_alarms(){

        $query="SELECT * FROM ".$this->table_name;

        $statement=$this->conn->prepare($query);
        $statement->execute();

        $lists=array();
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)){

            $lists[]=array(
                "id" => $row['id'],
                "date" => $row['date'],
                "lpn" => $row['lpn'],
                "category" => $row['category'],
                "description" => $row['description']
            );
        }

        return $lists;

    }

    /**
     * Create one Alarm
     * @return bool
     */
    public function createAlarm(){

        $query = "INSERT INTO " . $this->table_name . " SET lpn=:lpn, category=:category, description=:description, `date`=:created";

        $stmt = $this->conn->prepare($query);

        // sanitize
        $this->date=date('Y-m-d\TH:i:s');
        $this->lpn=htmlspecialchars(strip_tags($this->lpn));
        $this->category=htmlspecialchars(strip_tags($this->category));
        $this->description=htmlspecialchars(strip_tags($this->description));

        // bind values
        $stmt->bindParam(":created", $this->date);
        $stmt->bindParam(":lpn", $this->lpn);
        $stmt->bindParam(":category", $this->category);
        $stmt->bindParam(":description", $this->description);

        // execute query
        if($stmt->execute()){
            return true;
        }

        return false;
    }

    /**
     * Verif if Alarm Exist with LPN
     * @return bool
     */
    public function verif_exist(){

        $query = "SELECT * FROM " . $this->table_name . " WHERE lpn = ?";
        $stmt = $this->conn->prepare( $query );
        $stmt->bindParam(1, $this->lpn);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if(sizeof($row)>0){
            return $row;
        }

        return false;
    }

    /**
     * Modify Alarm
     * @return bool
     */
    public function modifyAlarm(){

        $alarm=$this->verif_exist();
        if($alarm!==false){

            $query = "UPDATE " . $this->table_name . " SET lpn=:lpn, category=:category, description=:description WHERE id = :id";

            // prepare query statement
            $stmt = $this->conn->prepare($query);

            // sanitize
            $this->lpn=htmlspecialchars(strip_tags($this->lpn));
            $this->category=htmlspecialchars(strip_tags($this->category));
            $this->description=htmlspecialchars(strip_tags($this->description));

            // bind values
            $stmt->bindParam(":lpn", $this->lpn);
            $stmt->bindParam(":category", $this->category);
            $stmt->bindParam(":description", $this->description);
            $stmt->bindParam(':id', $alarm['id']);

            // execute the query
            if($stmt->execute()){
                return true;
            }

            return false;

        }else{
            return -1;
        }
    }

    /**
     * Delete Alarm
     * @return bool|int
     */
    public function deleteAlarm(){

        $alarm=$this->verif_exist();
        if($alarm!==false){

            $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $alarm['id']);

            if($stmt->execute()){
                return true;
            }

            return false;

        }else{
            return "-1";
        }


    }
}