<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 09:15
 */
class Push
{

    private $conn;
    private $table_name = "push_alarms";

    public $id;
    public $date;
    public $lpn;
    public $category;
    public $description;
    public $device_id;

    /**
     * @return mixed
     */
    public function getDeviceId()
    {
        return $this->device_id;
    }

    /**
     * @param mixed $device_id
     */
    public function setDeviceId($device_id)
    {
        $this->device_id = $device_id;
    }

    /**
     * Alarms constructor.
     * @param $conn
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
    }


    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getLpn()
    {
        return $this->lpn;
    }

    /**
     * @param mixed $lpn
     */
    public function setLpn($lpn)
    {
        $this->lpn = $lpn;
    }

    /**
     * @return mixed
     */
    public function getCategory()
    {
        return $this->category;
    }

    /**
     * @param mixed $category
     */
    public function setCategory($category)
    {
        $this->category = $category;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * GET List Alarms Triggered
     */
    public function list_alarms_triggered(){

        $query="SELECT * FROM ".$this->table_name;

        $statement=$this->conn->prepare($query);
        $statement->execute();

        $lists=array();
        while ($row = $statement->fetch(PDO::FETCH_ASSOC)){

            $lists[]=array(
                "id" => $row['id'],
                "date" => $row['date'],
                "deviceid" => $row['deviceid'],
                "lpn" => $row['lpn'],
                "category" => $row['category'],
                "description" => $row['description']
            );
        }

        return $lists;

    }


    /**
     * Insert  push alarm
     */
    public function create(){

        $query = "INSERT INTO " . $this->table_name . " SET deviceid=:deviceid, lpn=:lpn, category=:category, description=:description, `date`=:created";

        $stmt = $this->conn->prepare($query);

        // sanitize
        $this->date=$this->date;
        $this->lpn=htmlspecialchars(strip_tags($this->lpn));
        $this->device_id=htmlspecialchars(strip_tags($this->device_id));
        $this->category=htmlspecialchars(strip_tags($this->category));
        $this->description=htmlspecialchars(strip_tags($this->description));

        // bind values
        $stmt->bindParam(":created", $this->date);
        $stmt->bindParam(":lpn", $this->lpn);
        $stmt->bindParam(":category", $this->category);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":deviceid", $this->device_id);

        // execute query
        if($stmt->execute()){
            return true;
        }

        return false;
    }
}