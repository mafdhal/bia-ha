<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 09:15
 */
class Transactions
{

    private $conn;
    private $table_name = "transactions";

    public $id;
    public $date;
    public $lpn;
    public $device_id;

    /**
     * @return mixed
     */
    public function getDeviceId()
    {
        return $this->device_id;
    }

    /**
     * @param mixed $device_id
     */
    public function setDeviceId($device_id)
    {
        $this->device_id = $device_id;
    }

    /**
     * Alarms constructor.
     * @param $conn
     */
    public function __construct($conn)
    {
        $this->conn = $conn;
    }


    /**
     * @return mixed
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * @param mixed $date
     */
    public function setDate($date)
    {
        $this->date = $date;
    }

    /**
     * @return mixed
     */
    public function getLpn()
    {
        return $this->lpn;
    }

    /**
     * @param mixed $lpn
     */
    public function setLpn($lpn)
    {
        $this->lpn = $lpn;
    }

    /**
     * Insert  push alarm
     */
    public function create(){

        $query = "INSERT INTO " . $this->table_name . " SET device=:deviceid, lpn=:lpn, `date`=:created";

        $stmt = $this->conn->prepare($query);

        // sanitize
        $this->date=$this->date;
        $this->lpn=htmlspecialchars(strip_tags($this->lpn));
        $this->device_id=htmlspecialchars(strip_tags($this->device_id));

        // bind values
        $stmt->bindParam(":created", $this->date);
        $stmt->bindParam(":lpn", $this->lpn);
        $stmt->bindParam(":deviceid", $this->device_id);

        // execute query
        if($stmt->execute()){
            return true;
        }

        return false;
    }
}