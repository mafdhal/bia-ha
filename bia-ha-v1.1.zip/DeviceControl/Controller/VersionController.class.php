<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 13:24
 */
class VersionController
{

    /**
     * Get Version
     * @return string
     */
    public static function getVersion(){

        $connection=new Connection();
        $version=new Versions($connection->db);

        $statmt=$version->version();
        $result=$statmt->fetch(PDO::FETCH_ASSOC);

        $response_xml=Body::version($result['version']);
        Log::set(date("Y-m-d H:i:s")." - Get Version :\n".$response_xml);
        return $response_xml;
    }

}