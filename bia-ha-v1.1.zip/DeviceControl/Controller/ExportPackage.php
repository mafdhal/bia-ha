<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 06/09/2018
 * Time: 14:19
 */
class ExportPackage
{

    /**
     * Get PSV File and read
     * @param $settings_ftp
     * @return array|bool
     */
    public static function ftp_output($settings_ftp){

        $date = strtotime("-1 day");
        $filename="PPA-".date('ymd',$date).".PSV";
        $ftp_server=$settings_ftp['input']['server_input'];
        $ftp_user_name=$settings_ftp['input']['username_input'];
        $ftp_user_pass=$settings_ftp['input']['password_input'];
        $remote_file = $settings_ftp['input']['path_input'].$filename;

        // set up basic connection
        Log::set(date("Y-m-d H:i:s")." - FTP Connect to : $ftp_server");
        $conn_id = @ftp_connect($ftp_server);
        if(!$conn_id){
            echo "Failed to connect to ".$ftp_server;
            Log::set(date("Y-m-d H:i:s")." - Failed to connect to ".$ftp_server);
            return false;
            exit;
        }else{

            Log::set(date("Y-m-d H:i:s")." - FTP connected successfully : ".$conn_id);
            // login with username and password
            Log::set(date("Y-m-d H:i:s")." - FTP Login to ".$ftp_server." with $ftp_user_name:$ftp_user_pass");
            $login_result = @ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);
            if($login_result){

                Log::set(date("Y-m-d H:i:s")." - FTP authenticated successfully.");
                //$filew=file_get_contents("ftp://".$ftp_user_name.":".$ftp_user_pass."@".$ftp_server."/".$remote_file);
                $handle=@fopen("ftp://".$ftp_user_name.":".$ftp_user_pass."@".$ftp_server."/".$remote_file,"r");
                if($handle){

                    Log::set(date("Y-m-d H:i:s")." - FTP Open 'ftp://".$ftp_user_name.":".$ftp_user_pass."@".$ftp_server."/".$remote_file."'");
                    $start=0;
                    $outputs=array();
                    while (($line = fgets($handle)) !== false) {
                        if($start>0 && ftell($handle)>$start){
                            $line=trim($line);
                            $params=explode(';',$line);
                            $outputs[]=$params;
                        }else{
                            if(strpos($line,'TradingDate')>-1){
                                $start=ftell($handle);
                            }
                        }
                    }

                    $ids=Functions::unique_multidim_array($outputs,4);
                    $lists=self::get_list_transactions($ids,$outputs);
                    $payments=self::get_outputs($lists);

                    return $payments;

                }else{
                    echo 'Failed To Open File.';
                    Log::set(date("Y-m-d H:i:s")." - Failed To Open File $remote_file");
                    exit;
                }

            }else{
                echo 'Error in FTP Login. Check your username or password';
                Log::set(date("Y-m-d H:i:s")." - Error in FTP Login. Check your username or password");
                exit;
            }
        }

    }

    /**
     * Get List By Device ID
     * @param $ids
     * @param $outputs
     * @return array
     */
    private static function get_list_transactions($ids,$outputs){
        $lists=array();
        foreach ($ids as $id){
            $lists[$id]=array();
            foreach ($outputs as $item){
                if($item[4]===$id){
                    $lists[$id][]=$item;
                }
            }
        }

        return $lists;
    }

    /**
     * Outputs
     * @param $lists
     * @return array
     */
    private static function get_outputs($lists){
        $payments=array();
        $date = strtotime("-1 day");
        $start_period=date('Ymd\T00:00:00',$date);
        $end_period=date('Ymd\T23:59:59',$date);

        foreach ($lists as $k=>$line_list){

            $payments[$k]=array(
                1=>array(
                    "park_id"=>"",
                    "source_id"=>Functions::key_value($k,'devices'),
                    "revenue_type"=>"Cash",
                    "amount"=>0,
                    "accounting_date"=>date('d-M-y'),
                    "start_period"=>$start_period,
                    "end_period"=>$end_period
                ),
                2=>array(
                    "park_id"=>"",
                    "source_id"=>Functions::key_value($k,'devices'),
                    "revenue_type"=>"Credit",
                    "amount"=>0,
                    "accounting_date"=>date('d-M-y'),
                    "start_period"=>$start_period,
                    "end_period"=>$end_period
                )
            );

            foreach ($line_list as $item){

                $payments[$k][1]['park_id']=Functions::key_value($item[1],'sites');
                $payments[$k][2]['park_id']=Functions::key_value($item[1],'sites');

                if((int)$item[10]==1){
                    $payments[$k][1]['amount']+=floatval($item[7]);
                }elseif ((int)$item[10]==2){
                    $payments[$k][2]['amount']+=floatval($item[7]);
                }
            }
        }

        return $payments;
    }


    /**
     * Upload File in Server
     * @param $settings_ftp
     * @param $outputs
     * @return bool
     */
    public static function ftp_input($settings_ftp,$outputs){

        $filename="CPMS_ERP_ParkingInfo_".date('YmdHis').".csv";


        $data = array();
        foreach ($outputs as $output){
            foreach ($output as $item){
                $data[]=$item['park_id'].','.$item['source_id'].','.$item['revenue_type'].','.$item['amount'].','.$item['accounting_date'].','.$item['start_period'].','.$item['end_period'];
            }
        }

        $file="ReportExport/".$filename;
        $csv = "Car Park ID,Source ID,Revenue Type,Amount,Accounting Date,Start Period,End Period \n";

        foreach ($data as $line){
            $csv.= $line."\n"; //Append data to csv
        }
        $csv_handler = fopen ($file,'w');
        fwrite ($csv_handler,$csv);
        fclose ($csv_handler);

        // set up basic connection

        self::ftp_upload($settings_ftp,$filename,$file);

    }
    private static function ftp_upload($settings_ftp,$filename,$file){

        $ftp_server=$settings_ftp['output']['server_output'];
        $ftp_user_name=$settings_ftp['output']['username_output'];
        $ftp_user_pass=$settings_ftp['output']['password_output'];
        $remote_file = $settings_ftp['output']['path_output'].$filename;
        Log::set(date("Y-m-d H:i:s")." - FTP Upload :");

        Log::set(date("Y-m-d H:i:s")." - FTP Connect to : $ftp_server");
        $conn_id = @ftp_connect($ftp_server);
        if(!$conn_id){
            echo "Failed to connect to ".$ftp_server;
            Log::set(date("Y-m-d H:i:s")." - Failed to connect to ".$ftp_server);
            return false;
            exit;
        }else{

            // login with username and password
            Log::set(date("Y-m-d H:i:s")." - FTP Login to ".$ftp_server." with $ftp_user_name:$ftp_user_pass");
            $login_result = @ftp_login($conn_id, $ftp_user_name, $ftp_user_pass);

            if($login_result){

                // upload a file
                if(ftp_put($conn_id, $remote_file, $file, FTP_ASCII)){
                    //echo "successfully uploaded $file\n";
                    echo "successfully uploaded $file\n";
                    Log::set(date("Y-m-d H:i:s")." - successfully uploaded to  $remote_file");
                    return true;
                    exit;
                }else{
                    echo "There was a problem while uploading $file\n";
                    Log::set(date("Y-m-d H:i:s")." - There was a problem while uploading to $remote_file");
                    return false;
                    exit;
                }
                // close the connection
                ftp_close($conn_id);
            }else{
                echo 'Error in FTP Login. Check your username or password';
                Log::set(date("Y-m-d H:i:s")." - Error in FTP Login. Check your username or password");
                exit;
            }
        }

    }
}