<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 13:24
 */
class PushController
{

    /**
     * Create a push alarm
     * @param $rest
     * @param $data
     */
    public static function push($rest,$data){

        $categories=array("High","Medium","Low");
        $connection=new Connection();
        $pushEntity=new Push($connection->db);

        Log::set(date("Y-m-d H:i:s")." - Push Alarm");
        if(isset($data) and !empty($data)){
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $alarm=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                self::push_alarm($alarm,$rest,$pushEntity,$categories);

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - Push Alarm : 422 \n$response_xml");
                $rest->response($response_xml,422);
            }
        }else{
            $response_xml=Body::error_response(-1,'Invalid XML Body','XML Body is required.');
            Log::set(date("Y-m-d H:i:s")." - Push Alarm : 500 \n$response_xml");
            $rest->response($response_xml,500);
        }

    }
    private static function push_alarm($item,$rest,$pushEntity,$categories){

        $connection=new Connection();
        $alarmsEntity=new Alarms($connection->db);
        $regex = '/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}$/';

        Log::set(date("Y-m-d H:i:s")." - Push Alarm : \n".json_encode($item));
        $alarmsEntity->lpn=$item->lpn;
        if($alarmsEntity->verif_exist()!==false){

            $alarm=$alarmsEntity->verif_exist();
            if(!$item->lpn or empty($item->lpn)){

                $response_xml=Body::error_response(-1,'Invalid LPN','Car license plate is required.');
                Log::set(date("Y-m-d H:i:s")." - Push Alarm : 500 \n$response_xml");
                $rest->response($response_xml,500);

            }elseif (!$item->date or empty($item->date) or !preg_match($regex,$item->date)){

                $now=(new DateTime())->format("Y-m-d\\TH:i:s");
                $response_xml=Body::error_response(-1,'Invalid Date','Alarm date is required and must be some format "'.$now.'".');
                Log::set(date("Y-m-d H:i:s")." - Push Alarm : 500 \n$response_xml");
                $rest->response($response_xml,500);
            }elseif (!$item->deviceid or empty($item->deviceid)){

                $response_xml=Body::error_response(-1,'Invalid Device ID','Device ID is required.');
                Log::set(date("Y-m-d H:i:s")." - Push Alarm : 500 \n$response_xml");
                $rest->response($response_xml,500);

            }else{

                $pushEntity->lpn=$item->lpn;
                $pushEntity->device_id=$item->deviceid;
                $pushEntity->category=$alarm['category'];
                $pushEntity->description=$alarm['description'];
                $pushEntity->date=$item->date;

                if($pushEntity->create()){
                    Log::set(date("Y-m-d H:i:s")." - Push Alarm : 204 OK \nNo Content");
                    DCApi::command($item->deviceid,0,$rest);
                    $rest->response('',204);
                }else{
                    $response_xml=Body::error_response(-1,'Unable to create Push Alarm.','Unable to create Push Alarm.');
                    Log::set(date("Y-m-d H:i:s")." - Push Alarm : 500 \n$response_xml");
                    $rest->response($response_xml,500);
                }
            }
        }
    }

    /**
     * List Alarms Triggered
     * @return mixed
     */
    public static function list_alarms_triggered($rest){

        $connection=new Connection();
        $push_alarms=new Push($connection->db);

        $result=$push_alarms->list_alarms_triggered();

        $response_xml=Body::list_alarms_triggered($result);

        @$valid_xml=simplexml_load_string($response_xml);
        if($valid_xml!==false){

            Log::set(date("Y-m-d H:i:s")." - List Alarms Triggered : 200 \n$response_xml");
            $rest->response($response_xml,200);

        }else{
            // Invalid XML
            Log::set(date("Y-m-d H:i:s")." - List Alarms Triggered : 422");
            $rest->response('',422);
        }

    }

    /**
     * Web Service LPN Triggered By jar File Camera Input.
     * @param $rest
     * @param $data
     */
    public static function lpn_triggered($rest,$data){
        $categories=array("High","Medium","Low");
        $connection=new Connection();
        $pushEntity=new Push($connection->db);
        $transactionEntity=new Transactions($connection->db);

        self::create_transaction($data,$transactionEntity);
        self::push_alarm($data,$rest,$pushEntity,$categories);

    }
    private static function create_transaction($data,$transactionEntity){

        if($data->lpn!="" and $data->date!="" and $data->deviceid!=""){
            $transactionEntity->lpn=$data->lpn;
            $transactionEntity->device_id=$data->deviceid;
            $transactionEntity->date=$data->date;

            $transactionEntity->create();
        }
    }

}