<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 14/08/2018
 * Time: 13:24
 */
class AlarmController
{

    /**
     * List Alarms Controller
     * @return mixed
     */
    public static function list_alarms($rest,$from,$to){

        $connection=new Connection();
        $alarms=new Alarms($connection->db);
        $list_alarms=array();
        $regex = '/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}$/';

        $result=$alarms->list_alarms();
        if($from!==null){
            if(preg_match($regex,$from)){

                if($to===null){
                    $from=(new DateTime(str_replace('T',' ',$from)))->format('Y-m-d H:i');
                    foreach ($result as $alarm){
                        $alarm_date=(new DateTime(str_replace('T',' ',$alarm['date'])))->format('Y-m-d H:i');
                        if(new DateTime($alarm_date)>=new DateTime($from)){
                            $list_alarms[]=$alarm;
                        }
                    }

                }else{
                    if(preg_match($regex,$to)){
                        $from=(new DateTime(str_replace('T',' ',$from)))->format('Y-m-d H:i');
                        $to=(new DateTime(str_replace('T',' ',$to)))->format('Y-m-d H:i');
                        foreach ($result as $alarm){
                            $alarm_date=(new DateTime(str_replace('T',' ',$alarm['date'])))->format('Y-m-d H:i');
                            if(new DateTime($alarm_date)>=new DateTime($from) and new DateTime($alarm_date)<=new DateTime($to)){
                                $list_alarms[]=$alarm;
                            }
                        }
                    }else{

                        $now=(new DateTime())->format("Y-m-d\\TH:i:s");
                        $response_xml_error=Body::error_response(-1,'Invalid format date','The format of `To` date must be some "'.$now.'"');
                        $rest->response($response_xml_error,500);
                    }
                }
            }else{

                $now=(new DateTime())->format("Y-m-d\\TH:i:s");
                $response_xml_error=Body::error_response(-1,'Invalid format date','The format of `From` date must be some "'.$now.'"');
                $rest->response($response_xml_error,500);
            }

        }else{
            $list_alarms=$result;
        }

        $response_xml=Body::list_alarms($list_alarms);
        Log::set(date("Y-m-d H:i:s")." - List of Alarms : \n".$response_xml);

        @$valid_xml=simplexml_load_string($response_xml);
        if($valid_xml!==false){

            $rest->response($response_xml,200);

        }else{
            // Invalid XML
            $rest->response('',422);
        }

    }

    /**
     * Create an Alarm
     * @param $rest
     * @param $data
     */
    public static function create($rest,$data){

        $categories=array("High","Medium","Low");
        $connection=new Connection();
        $alarmsEntity=new Alarms($connection->db);

        if(isset($data) and !empty($data)){
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $alarms=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                $numb_alarm=sizeof($alarms->alarm);
                if($numb_alarm>0){
                    if($numb_alarm>1){
                        $i=1;
                        foreach ($alarms->alarm as $key=>$item){
                            self::create_alarm($item,$rest,$alarmsEntity,$categories,$i,$numb_alarm);
                            $i++;
                        }
                    }else{
                        $item=$alarms->alarm;
                        self::create_alarm($item,$rest,$alarmsEntity,$categories,1,$numb_alarm);
                    }
                }else{
                    $response_xml=Body::error_response(-1,'Not Exist Alarm','Not found alarm input.');
                    Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
                    $rest->response($response_xml,500);
                }

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - Create Alarm : 422 \n".$response_xml);
                $rest->response($response_xml,422);
            }
        }else{
            $response_xml=Body::error_response(-1,'Invalid XML Body','XML Body is required.');
            Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);
        }

    }
    private static function create_alarm($item,$rest,$alarmsEntity,$categories,$i,$numb_alarm){

        Log::set(date("Y-m-d H:i:s")." - Create Alarm : \n".json_encode($item));
        if(!$item->lpn or empty($item->lpn)){

            $response_xml=Body::error_response(-1,'Invalid LPN','Car license plate is required.');
            Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);

        }elseif (!$item->description or empty($item->description)){

            $response_xml=Body::error_response(-1,'Invalid Description','Alarm description is required.');
            Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);
        }elseif (!$item->category or empty($item->category) or !in_array($item->category,$categories)){

            $response_xml=Body::error_response(-1,'Invalid Category','Alarm category is required and must be High, Medium or Low.');
            Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);

        }else{

            $alarmsEntity->lpn=$item->lpn;
            if($alarmsEntity->verif_exist()!==false){

                $response_xml=Body::error_response(-1,'Alarm exist.','Some Alarm exist with this LPN.');
                Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
                $rest->response($response_xml,500);

            }else{
                $alarmsEntity->category=$item->category;
                $alarmsEntity->description=$item->description;

                if($alarmsEntity->createAlarm()){
                    if($i==$numb_alarm){
                        Log::set(date("Y-m-d H:i:s")." - Create Alarm : 204 OK \nNo Content");
                        $rest->response('',204);
                    }
                }else{
                    $response_xml=Body::error_response(-1,'Unable to create Alarm.','Unable to create Alarm.');
                    Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
                    $rest->response($response_xml,500);
                }
            }
        }
    }

    /**
     * Delete Alarm
     * @param $rest
     * @param $data
     */
    public static function delete($rest,$data){

        $categories=array("High","Medium","Low");
        $connection=new Connection();
        $alarmsEntity=new Alarms($connection->db);

        if(isset($data) and !empty($data)){
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $alarms=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                $numb_alarm=sizeof($alarms->alarm);
                if($numb_alarm>0){
                    if($numb_alarm>0){
                        if($numb_alarm>1){
                            $i=1;
                            foreach ($alarms->alarm as $key=>$item){
                                self::delete_alarm($item,$rest,$alarmsEntity,$categories,$i,$numb_alarm);
                                $i++;
                            }
                        }else{
                            $item=$alarms->alarm;
                            self::delete_alarm($item,$rest,$alarmsEntity,$categories,1,$numb_alarm);
                        }
                    }else{
                        $response_xml=Body::error_response(-1,'Not Exist Alarm','Not found alarm input.');
                        Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
                        $rest->response($response_xml,500);
                    }
                }else{
                    $response_xml=Body::error_response(-1,'Not Exist Alarm','Not found alarm input.');
                    Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
                    $rest->response($response_xml,500);
                }

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - Create Alarm : 422 \n".$response_xml);
                $rest->response($response_xml,422);
            }
        }else{
            $response_xml=Body::error_response(-1,'Invalid XML Body','XML Body is required.');
            Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);
        }
    }
    private static function delete_alarm($item,$rest,$alarmsEntity,$categories,$i,$numb_alarm){

        Log::set(date("Y-m-d H:i:s")." - Delete Alarm : \n".json_encode($item));
        if(!$item->lpn or empty($item->lpn)){

            $response_xml=Body::error_response(-1,'Invalid LPN','Car license plate is required.');
            Log::set(date("Y-m-d H:i:s")." - Delete Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);

        }elseif (!$item->description or empty($item->description)){

            $response_xml=Body::error_response(-1,'Invalid Description','Alarm description is required.');
            Log::set(date("Y-m-d H:i:s")." - Delete Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);
        }elseif (!$item->category or empty($item->category) or !in_array($item->category,$categories)){

            $response_xml=Body::error_response(-1,'Invalid Category','Alarm category is required and must be High, Medium or Low.');
            Log::set(date("Y-m-d H:i:s")." - Delete Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);

        }else{

            $alarmsEntity->lpn=$item->lpn;
            if($alarmsEntity->deleteAlarm()){
                if($i==$numb_alarm){
                    Log::set(date("Y-m-d H:i:s")." - Delete Alarm : 204 OK \n No Content");
                    $rest->response('',204);
                }
            }else{
                $response_xml=Body::error_response(-1,'Unable to delete Alarm.','Unable to delete Alarm.');
                Log::set(date("Y-m-d H:i:s")." - Delete Alarm : 500 \n".$response_xml);
                $rest->response($response_xml,500);
            }

        }
    }

    /**
     * Update Alarm
     * @param $rest
     * @param $data
     */
    public static function update($rest,$data){

        $categories=array("High","Medium","Low");
        $connection=new Connection();
        $alarmsEntity=new Alarms($connection->db);

        if(isset($data) and !empty($data)){
            @$valid_xml=simplexml_load_string($data);
            if($valid_xml!==false){

                $alarms=simplexml_load_string($data, "SimpleXMLElement", LIBXML_NOCDATA);
                $numb_alarm=sizeof($alarms->alarm);
                if($numb_alarm>0){
                    if($numb_alarm>1){
                        $i=1;
                        foreach ($alarms->alarm as $key=>$item){
                            self::update_alarm($item,$rest,$alarmsEntity,$categories,$i,$numb_alarm);
                            $i++;
                        }
                    }else{
                        $item=$alarms->alarm;
                        self::update_alarm($item,$rest,$alarmsEntity,$categories,1,$numb_alarm);
                    }
                }else{
                    $response_xml=Body::error_response(-1,'Not Exist Alarm','Not found alarm input.');
                    Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
                    $rest->response($response_xml,500);
                }

            }else{
                $response_xml=Body::error_response(202,'Malformed XML','The XML you provided was not well-formed or did not validate against our published schema.');
                Log::set(date("Y-m-d H:i:s")." - Create Alarm : 422 \n".$response_xml);
                $rest->response($response_xml,422);
            }
        }else{
            $response_xml=Body::error_response(-1,'Invalid XML Body','XML Body is required.');
            Log::set(date("Y-m-d H:i:s")." - Create Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);
        }

    }
    private static function update_alarm($item,$rest,$alarmsEntity,$categories,$i,$numb_alarm){

        Log::set(date("Y-m-d H:i:s")." - Update Alarm : \n".json_encode($item));
        if(!$item->lpn or empty($item->lpn)){

            $response_xml=Body::error_response(-1,'Invalid LPN','Car license plate is required.');
            Log::set(date("Y-m-d H:i:s")." - Update Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);

        }elseif (!$item->description or empty($item->description)){

            $response_xml=Body::error_response(-1,'Invalid Description','Alarm description is required.');
            Log::set(date("Y-m-d H:i:s")." - Update Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);
        }elseif (!$item->category or empty($item->category) or !in_array($item->category,$categories)){

            $response_xml=Body::error_response(-1,'Invalid Category','Alarm category is required and must be High, Medium or Low.');
            Log::set(date("Y-m-d H:i:s")." - Update Alarm : 500 \n".$response_xml);
            $rest->response($response_xml,500);

        }else{

            $alarmsEntity->lpn=$item->lpn;
            if($alarmsEntity->verif_exist()===false){

                $response_xml=Body::error_response(-1,'Alarm not exist.','No found Alarm.');
                Log::set(date("Y-m-d H:i:s")." - Update Alarm : 500 \n".$response_xml);
                $rest->response($response_xml,500);

            }else{
                $alarmsEntity->category=$item->category;
                $alarmsEntity->description=$item->description;

                if($alarmsEntity->modifyAlarm()){
                    if($i==$numb_alarm){
                        Log::set(date("Y-m-d H:i:s")." - Update Alarm : 204 OK \nNo Content");
                        $rest->response('',204);
                    }
                }else{
                    $response_xml=Body::error_response(-1,'Unable to create Alarm.','Unable to create Alarm.');
                    Log::set(date("Y-m-d H:i:s")." - Update Alarm : 500 \n".$response_xml);
                    $rest->response($response_xml,500);
                }
            }

        }

    }
}