<?php

/**
 * Created by PhpStorm.
 * User: Imed
 * Date: 04/05/2018
 * Time: 10:01
 */
class Connection extends REST
{

    public $data = "";

    const DB_SERVER = "127.0.0.1";
    const DB_USER = "root";
    const DB_PASSWORD = "innotec";
    const DB = "device_control_bahrain";

    public $db = NULL;

    public function __construct(){
        $this->dbConnect();
    }

    /*
     *  Database connection
    */
    private function dbConnect(){

        $options = array(
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        );
        $this->db = new PDO('mysql:host='.self::DB_SERVER.';dbname='.self::DB.';',self::DB_USER, self::DB_PASSWORD,$options);
    }

}